---
name: Salud Mendoza Design System
colors:
  surface: '#f9f9ff'
  surface-dim: '#d8dae1'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fa'
  surface-container: '#ecedf5'
  surface-container-high: '#e7e8ef'
  surface-container-highest: '#e1e2e9'
  on-surface: '#191c21'
  on-surface-variant: '#414751'
  inverse-surface: '#2e3036'
  inverse-on-surface: '#eff0f7'
  outline: '#727782'
  outline-variant: '#c1c6d3'
  surface-tint: '#0d5fac'
  primary: '#004a8a'
  on-primary: '#ffffff'
  primary-container: '#1462af'
  on-primary-container: '#cbdeff'
  inverse-primary: '#a5c8ff'
  secondary: '#006a6a'
  on-secondary: '#ffffff'
  secondary-container: '#90efef'
  on-secondary-container: '#006e6e'
  tertiary: '#484a4a'
  on-tertiary: '#ffffff'
  tertiary-container: '#606161'
  on-tertiary-container: '#dcdddd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a5c8ff'
  on-primary-fixed: '#001c3a'
  on-primary-fixed-variant: '#004785'
  secondary-fixed: '#93f2f2'
  secondary-fixed-dim: '#76d6d5'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f4f'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9ff'
  on-background: '#191c21'
  surface-variant: '#e1e2e9'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-3xs: 0.125rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  grid-margin-desktop: 2rem
  grid-margin-mobile: 1rem
  grid-gutter: 1.5rem
---

## Brand & Style

This design system embodies an institutional, authoritative, and deeply accessible public sector aesthetic tailored for provincial healthcare administration. It prioritizes clarity, trust, and inclusivity to bridge administrative gaps for all citizens.

- **Brand Personality:** Utilitarian, reliable, calm, and approachable. It conveys institutional competence while maintaining empathy for patients and medical staff.
- **Target Audience:** Provincial citizens, patients managing personal and dependent health records, medical professionals, and administrative staff across various digital literacy levels.
- **Emotional Response:** Reassurance, clarity, security, and efficiency. The interface reduces cognitive load in high-stress medical contexts.
- **Design Style:** Corporate / Modern, heavily rooted in accessible UI patterns, structured data displays, and high-contrast compliance with WCAG 2.1 AA standards.

## Colors

The color system relies on vibrant institutional blues (`#1462AF`), trustworthy teal secondary accents, and clean white tertiary elements, grounded by high-contrast neutrals to ensure optimal readability across public health portals.

- **Primary Color (`#1462AF`):** Bright institutional blue used for primary structural elements, headers, and high-emphasis actions, communicating clarity, accessibility, and authority.
- **Secondary Color (`#008080`):** Clinical teal utilized for interactive elements, secondary actions, and positive state indicators.
- **Tertiary Color (`#FFFFFF`):** Clean white accent used for contrasting elements and surface highlights.
- **Neutral Palette (`#F4F6F8` base, `#FFFFFF` surfaces):** Clean, high-contrast light backgrounds designed to reduce visual fatigue during prolonged administrative tasks.
- **Semantic Status Colors:** 
  - `urgent-red` (`#D32F2F`) for critical alerts and presencial attention queues.
  - `success-teal` (`#2E7D32`) for active/available inventory and validated prescriptions.
  - `warning-amber` (`#ED6C02`) for pending validations and low stock warnings.

## Typography

The typography system uses **Inter** exclusively to maximize legibility across digital portals, medical documents, and mobile screens. 

- **Hierarchy:** Strict proportional scaling ensures clear information architecture for complex health dashboards, medical histories, and prescription codes.
- **Accessibility:** Generous line heights and robust default font weights (400 for body, 500-700 for structural elements) comply with inclusive design guidelines for aging populations.

## Layout & Spacing

The layout model is built on a responsive fluid grid system designed to adapt seamlessly between high-density desktop control panels used by medical staff and touch-optimized mobile interfaces used by citizens.

- **Grid Architecture:** 12-column fluid grid on desktop, collapsing to 4 columns on mobile devices.
- **Spacing Rhythm:** Based on an 8px (0.5rem) foundational base unit, ensuring predictable and scannable vertical rhythms across administrative forms, dashboards, and modal dialogs.
- **Adaptability:** Generous touch targets (minimum 48x48px) are enforced on mobile views to support users with varying motor skills and device types.

## Elevation & Depth

Visual hierarchy is conveyed primarily through clean structural layering and low-contrast outlines rather than heavy drop shadows, maintaining a flat, modern, and trustworthy institutional feel.

- **Tonal Layering:** Surface containers use subtle background color differentiation to separate content zones (e.g., separating sidebar navigation from the main dashboard canvas).
- **Modals & Overlays:** Elevated components such as modals and dropdown menus employ soft, diffused ambient shadows (`0px 8px 24px rgba(20, 98, 175, 0.12)`) to signal interactivity and focus above the base layer.
- **Borders & Dividers:** Clean 1px solid borders (`#E0E0E0`) define card boundaries and form inputs, ensuring clear component separation without visual clutter.

## Shapes

The shape language uses a soft, restrained rounding level (`1`) that balances approachability with institutional formality.

- **Border Radius Standards:** 
  - Base components (inputs, buttons, standard badges): `0.25rem` (4px).
  - Containers and cards: `0.5rem` (8px).
  - Modals and prominent dialog surfaces: `0.75rem` (12px).
- **Rationale:** Avoids overly playful pill-shapes or harsh 0px sharp corners, striking a balance that feels professional, secure, and modern for public health software.

## Components

Consistency across the public health portal is maintained through standardized, accessible component patterns designed for high-efficiency workflows.

- **Buttons:** Primary actions use solid institutional blue (`#1462AF`) with white text; secondary actions use teal outlines (`#008080`). Destructive or urgent actions use `urgent-red`. All buttons maintain explicit focus rings for keyboard navigation.
- **Input Fields:** Clearly labeled fields with high-contrast borders, inline error messaging, and helper text underneath. Required fields are explicitly marked to streamline administrative form completion.
- **Cards:** Used extensively for patient control panels, appointment summaries, and prescription tracking. Cards requiring urgent attention feature a distinct left accent border in `urgent-red`.
- **Chips & Status Badges:** Compact elements utilizing semantic colors to instantly communicate states like "Disponible", "Pendiente", or "Retirado".
- **Lists & Tables:** High-density data tables featuring alternating row backgrounds, sticky headers for long records, and direct action triggers (e.g., viewing medical history or downloading QR prescriptions).
- **Checkboxes & Radios:** Scaled for high touch-target compliance, ensuring effortless selection on both desktop and mobile viewports.
- **Additional Components:** QR code / barcode display containers for pharmacy validations, DICOM medical image viewer wrappers, and multi-file upload zones supporting PDF, JPG, and PNG formats.