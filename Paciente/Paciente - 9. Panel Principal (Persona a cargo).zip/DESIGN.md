---
name: Salud Mendoza
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#424752'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#115cb9'
  primary: '#003f87'
  on-primary: '#ffffff'
  primary-container: '#0056b3'
  on-primary-container: '#bbd0ff'
  inverse-primary: '#acc7ff'
  secondary: '#006d43'
  on-secondary: '#ffffff'
  secondary-container: '#75f8b3'
  on-secondary-container: '#007147'
  tertiary: '#404242'
  on-tertiary: '#ffffff'
  tertiary-container: '#575959'
  on-tertiary-container: '#cfd0d0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a40'
  on-primary-fixed-variant: '#004491'
  secondary-fixed: '#78fbb6'
  secondary-fixed-dim: '#59de9b'
  on-secondary-fixed: '#002111'
  on-secondary-fixed-variant: '#005232'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-unit: 4px
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  margin-page: 24px
---

## Brand & Style

This design system establishes a professional, reliable, and accessible visual language tailored for public healthcare infrastructure. The brand personality is grounded, systematic, and deeply institutional, projecting trust and care across a diverse demographic ranging from pediatric patients managed by tutors to older adults.

The chosen design style is **Corporate / Modern**, utilizing a clean, highly structured, and utilitarian foundation (Material/HIG-inspired) that prioritizes clarity, error prevention, and cognitive ease under stressful or urgent medical scenarios. Visual flourishes are stripped away in favor of high-contrast readability, precise alignment, and predictable interactive patterns.

## Colors

The color architecture relies on a dependable institutional blue as the primary anchor, paired with a vibrant health-focused teal/emerald accent to signal successful actions, health metrics, and active states. A clean, clinical off-white/light-gray forms the neutral background system to reduce eye strain during prolonged administrative tasks.

- **Primary (`#0056B3`):** Used for primary actions, active navigation items, headers, and key structural containers.
- **Secondary / Accent (`#00A86B`):** Applied to positive indicators, availability badges (e.g., pharmacy stock), and success confirmations.
- **Tertiary (`#FDFDFD`):** Applied as a clean, crisp highlight or subtle alternate container tone within structural layouts.
- **Neutrals (`#F4F6F9` background, `#1E293B` text):** Optimized for maximum contrast ratios, ensuring effortless readability for users with low vision.
- **Semantic States:** Dedicated tones for alerts (`#D9381E`) and warnings (`#F59E0B`) guide users through critical pathways like prescription errors or urgent triage notices.

## Typography

Typography is systematic, utilitarian, and built around legibility across all digital touchpoints. Utilizing the **Inter** typeface, the type scale establishes a strict hierarchy that makes dense medical records, scheduling tables, and prescription tokens instantly scannable. 

- **Scale & Hierarchy:** Font weights are intentionally limited to regular (400), medium (500), and bold (600/700) to maintain crisp rendering on low-res hospital displays and mobile screens alike.
- **Accessibility:** Line heights are kept generous relative to font sizes to accommodate elderly patients and users accessing records under rushed conditions. Large headings automatically scale down on mobile viewports to prevent clipping.

## Layout & Spacing

The layout model relies on a strict **fluid grid system** built on a foundational 4px/8px spacing rhythm. This guarantees predictable spatial relationships between complex data tables, medical dashboards, and patient forms.

- **Breakpoints:** Adapt fluidly across mobile (< 640px), tablet (640px – 1024px), and desktop (> 1024px). On mobile form factors, page margins collapse to 16px to maximize data density, expanding to 32px on desktop dashboards.
- **Content Reflow:** Multi-column appointment calendars and patient management panels stack vertically on mobile devices, ensuring that touch targets remain thumb-friendly and never crowded.

## Elevation & Depth

Visual hierarchy and spatial separation are achieved primarily through **tonal layers and low-contrast outlines**, avoiding heavy drop shadows to maintain a clean, clinical aesthetic. 

- **Surfaces:** Use tiered surface colors (`#FFFFFF` cards resting on `#F4F6F9` backgrounds) to separate structural modules like doctor schedules, pharmacy inventory tables, and patient check-in queues.
- **Borders & Dividers:** Subtle, low-opacity borders (`#CBD5E1`) delineate interactive regions. Modals and floating action panels utilize gentle, diffused ambient shadows with minimal opacity to establish clear foreground z-index separation without visual clutter.

## Shapes

The shape language utilizes a **soft** roundedness profile (0.25rem to 0.75rem border-radius), striking a balance between clinical precision and approachable human care. 

- **Containers & Controls:** Input fields, buttons, and cards feature restrained, consistent corner rounding (`8px` for standard interactive elements, `12px` for prominent modal cards). Sharp 0px corners are reserved exclusively for data tables and strict grid alignments where maximum boundary efficiency is required.

## Components

Components are engineered for high-frequency clinical environments, emphasizing fault tolerance, speed, and absolute clarity.

- **Buttons:** Primary actions utilize solid institutional blue (`#0056B3`) with rounded-lg corners. Secondary actions feature ghost or outlined styles. Destructive actions (e.g., cancelling an appointment or revoking a prescription) use semantic alert red.
- **Input Fields:** Generous touch targets with clear inline labels, high-contrast borders, and prominent validation error states directly beneath the field. Required fields are explicitly marked.
- **Cards:** Used extensively in dashboards for patient queues, doctor schedules, and pharmacy stock tracking. Urgent items feature a prominent left accent border in alert red or warning amber.
- **Chips & Badges:** Pill-shaped indicators used for status tags (e.g., *En Espera*, *Disponible*, *Bajo Stock*, *Retirado*), color-coded with semantic background tints.
- **Checkboxes & Radio Buttons:** Scaled up slightly beyond standard sizing to ensure easy selection for older adults or users interacting via touch kiosks.
- **Lists & Tables:** Compact data rows with alternating subtle background shading for dense medical histories, featuring inline action triggers for digital prescriptions (QR/Barcodes) and document downloads (PDF/JPG).